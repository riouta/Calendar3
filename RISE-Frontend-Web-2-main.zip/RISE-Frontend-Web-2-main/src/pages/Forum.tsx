import React from 'react';

export interface IForumPageProps{}

const ForumPage: React.FunctionComponent<IForumPageProps> = (props) => {
    return (
        <div>
            <p>This is Forum Page</p>
        </div>    
    )
}

export default ForumPage;