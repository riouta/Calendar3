import React from 'react';

export interface INotesPageProps{}

const NotesPage: React.FunctionComponent<INotesPageProps> = (props) => {
    return (
        <div>
            <p>This is Notes Page</p>
        </div>    
    )
}

export default NotesPage;